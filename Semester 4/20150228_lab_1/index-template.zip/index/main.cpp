
using namespace std;

//void IndexV1(int argc, char* argv[]);
//void IndexV2(int argc, char* argv[]);
//void IndexV3(int argc, char* argv[]);
//void IndexV4(int argc, char* argv[]);
//void IndexV5(int argc, char* argv[]);

int main(int argc, char *argv[]) {
  //IndexV1(argc, argv);
  //IndexV2(argc, argv);
  //IndexV3(argc, argv);
  //IndexV4(argc, argv);
  //IndexV5(argc, argv);
}
