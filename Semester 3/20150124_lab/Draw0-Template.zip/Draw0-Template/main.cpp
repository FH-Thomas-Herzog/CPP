#include <iostream>
#include <MLApplication.h>
#include "DrawApp.h"

using namespace std;
using namespace ML;

int main() {

  return 0;
}
