#include "DrawApp.h"
#include "DrawWin.h"
#include <MLString.h>

using namespace ML;

DrawApp::DrawApp() : Application("Draw Application") {
 
}

DrawApp::~DrawApp() { /* nothing to do */ }

void DrawApp::OpenNewWindow() {
 
}

void DrawApp::BuildMenus() {
  
}
