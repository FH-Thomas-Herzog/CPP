/*
 * Queue.h
 *
 *  Created on: Nov 29, 2014
 *      Author: cchet
 */

#ifndef QUEUE_H_
#define QUEUE_H_

#include <iostream>
#include <string>
#include "Data.h"

class Queue {

private:
	int start;
	int capacity;
	int count;
	Data** data;
	inline int at(int i) const {
		return (start + i) % capacity;
	}

public:
	explicit Queue(int cp);
	~Queue(void);
	Queue(const Queue& queue);

	bool isEmpty(void) const;
	bool isFull(void) const;

	void enqueue(Data* item);
	Data* dequeue(void);
	void clear(void);
	Queue& operator=(const Queue& q);
	bool operator==(const Queue& q);
	inline bool operator!=(const Queue& q) {
		return !operator ==(q);
	}

	friend std::ostream& operator<<(std::ostream & os, const Queue & s);
};
#endif /* QUEUE_H_ */
